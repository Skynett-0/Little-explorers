package com.rupertkaleli.littleexplorers

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Forest = Color(0xFF174A3B)
private val Leaf = Color(0xFFE8F5DF)
private val Gold = Color(0xFFFFD45C)
private val Ink = Color(0xFF20352D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LittleExplorersApp() }
    }
}

@Composable
fun LittleExplorersApp() {
    var page by remember { mutableStateOf("Home") }
    var stars by remember { mutableIntStateOf(0) }
    var quizAnswer by remember { mutableStateOf("") }
    var quizDone by remember { mutableStateOf(false) }
    var letter by remember { mutableStateOf("A") }
    var count by remember { mutableIntStateOf(1) }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Forest, secondary = Color(0xFFFFA94D), background = Color(0xFFFFFCF5)
    )) {
        Scaffold(
            containerColor = Color(0xFFFFFCF5),
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Home", "Jungle", "Learn", "Games", "Parent").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = { Text(when(item) {
                                "Home" -> "🏠"; "Jungle" -> "🐾"; "Learn" -> "🔤"
                                "Games" -> "🧩"; else -> "👨‍👩‍👧"
                            }, fontSize = 19.sp) },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("🌈 LITTLE EXPLORERS", color = Forest, fontWeight = FontWeight.Black, fontSize = 20.sp)
                        Text("Big adventures for little minds", color = Color.Gray, fontSize = 12.sp)
                    }
                    Surface(color = Color(0xFFFFF1C7), shape = RoundedCornerShape(18.dp)) {
                        Text("⭐ $stars", modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            fontWeight = FontWeight.Bold, color = Ink)
                    }
                }

                when (page) {
                    "Home" -> {
                        Surface(color = Forest, shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("🌴 🦁 🐘 🐒 🌴", fontSize = 34.sp)
                                Text("Hello, Little Explorer!", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                                Text("A friendly world of stories, games and discovery.", color = Color(0xFFE4F4E9))
                                Text("Meet Leo, Ellie and Momo!", color = Gold, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text("Choose your adventure", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
                        val adventures = listOf(
                            Triple("🐒 Jungle World", "Meet amazing animals", "Jungle"),
                            Triple("🎵 Music Land", "Songs and rhymes", "Songs"),
                            Triple("🔤 Learning Land", "Letters and numbers", "Learn"),
                            Triple("🧩 Fun Games", "Play and discover", "Games")
                        )
                        LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                            items(adventures) { item ->
                                AdventureCard(item.first, item.second) { page = item.third }
                            }
                        }
                    }
                    "Jungle" -> {
                        Text("🐾 Jungle animal quiz", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
                        Text("Which animal is known as the king of the jungle?", fontSize = 18.sp)
                        Text("🦁       🐘       🐒       🦒", fontSize = 38.sp)
                        listOf("Lion 🦁", "Elephant 🐘", "Monkey 🐒", "Giraffe 🦒").forEach { answer ->
                            OutlinedButton(onClick = {
                                quizAnswer = answer
                                if (answer.startsWith("Lion") && !quizDone) { stars++; quizDone = true }
                            }, modifier = Modifier.fillMaxWidth()) { Text(answer) }
                        }
                        if (quizAnswer.startsWith("Lion")) Text("🎉 Fantastic! You earned a star!", color = Forest, fontWeight = FontWeight.Bold)
                        else if (quizAnswer.isNotEmpty()) Text("Good try! Have another go. 🌟")
                        TextButton(onClick = { quizAnswer = ""; quizDone = false }) { Text("Play again") }
                    }
                    "Learn" -> {
                        Text("🔤 Let's learn our letters!", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Surface(color = Color(0xFFE7F2FF), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(letter, fontSize = 76.sp, fontWeight = FontWeight.Black, color = Color(0xFF2865A0))
                                Text(when(letter) { "A" -> "🍎 Apple"; "B" -> "⚽ Ball"; "C" -> "🐱 Cat"; else -> "🐶 Dog" },
                                    fontSize = 28.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("A","B","C","D").forEach { l -> Button(onClick = { letter = l }) { Text(l) } }
                        }
                        Text("Tap a letter to discover a new word.")
                    }
                    "Games" -> {
                        Text("🔢 Count the jungle fruits!", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text((1..count).joinToString(" ") { "🍎" }, fontSize = 38.sp)
                        Text("How many apples can you see?", fontSize = 18.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            (1..4).forEach { n -> OutlinedButton(onClick = { count = n }) { Text("$n") } }
                        }
                        Button(onClick = { stars++; page = "Home" }) { Text("Finish activity ⭐") }
                    }
                    "Songs" -> {
                        Text("🎵 Music Land", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("🎶 🐘 🦁 🐒 🎶", fontSize = 42.sp)
                        Text("Sing along to familiar favourites:")
                        listOf("Twinkle, Twinkle, Little Star", "Old MacDonald Had a Farm", "The Wheels on the Bus").forEach {
                            Card(Modifier.fillMaxWidth()) { Text("🎵  $it", Modifier.padding(16.dp), fontWeight = FontWeight.SemiBold) }
                        }
                        Text("Audio and animated sing-alongs are planned for the next release.", color = Color.Gray, fontSize = 12.sp)
                    }
                    else -> {
                        Text("👨‍👩‍👧 Parent corner", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("Little Explorers is designed for children aged 3–8.")
                        Text("• No public chat or social sharing")
                        Text("• No ads in this starter version")
                        Text("• No in-app purchases in this starter version")
                        Text("• Stars are local demo rewards and are not yet saved between sessions")
                        Text("Publisher: Rupert Kaleli", fontWeight = FontWeight.Bold)
                        Text("Before public release, add a parent gate, privacy policy, age-appropriate testing and a secure way to manage settings.")
                    }
                }
            }
        }
    }
}

@Composable
private fun AdventureCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(onClick = onClick, shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Leaf),
        modifier = Modifier.height(128.dp)) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.Center) {
            Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Forest)
            Spacer(Modifier.height(6.dp))
            Text(subtitle, fontSize = 12.sp, color = Ink)
        }
    }
}
