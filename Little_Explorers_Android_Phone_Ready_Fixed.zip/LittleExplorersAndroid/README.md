# Little Explorers – Android starter app

**Publisher display name:** Rupert Kaleli  
**Package ID:** `com.rupertkaleli.littleexplorers`  
**Target audience:** Children aged 3–8  
**Technology:** Kotlin + Jetpack Compose

## Included in this starter
- Home screen with four activity areas
- Jungle animal multiple-choice quiz and star reward
- Letter-learning activity (A–D)
- Simple counting game
- Nursery rhyme catalogue placeholder
- Parent information screen
- No ads, analytics, public chat, or in-app purchases

## Open and run
1. Install Android Studio (current stable version).
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `LittleExplorersAndroid` folder.
4. Allow Gradle sync to complete.
5. Run on an Android emulator or connect an Android phone with USB debugging enabled.

## Build an APK
In Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The debug APK is for testing. A signed release build and Google Play developer account are required for publishing.

## Important before publishing for children
This is a starter prototype, not a finished child-directed commercial release. Add and test a parent gate, privacy policy, data-safety disclosures, accessible audio controls, content review, and the required Google Play Families policy compliance. Do not add behavioural advertising or collect children's personal data without a compliant legal basis and parental processes. The app currently stores no progress persistently; stars reset when the process restarts.

## Branding
The app uses emoji and native Compose components as temporary art placeholders. Replace them with original, licensed character illustrations and recorded voice/audio before release.

## Build a test APK using only your phone (GitHub Actions)
1. Create a GitHub account or sign in at https://github.com.
2. In your browser, create a **new public or private repository** named `LittleExplorers`.
3. Extract the ZIP on your phone, then upload the project files and folders to the repository. Make sure the `.github/workflows/build-apk.yml` file is included. If your phone's file picker hides `.github`, use GitHub's web editor to create that folder and file manually.
4. Open the repository's **Actions** tab, select **Build Little Explorers APK**, then choose **Run workflow**.
5. When the run finishes successfully, open it and download the `Little-Explorers-debug-apk` artifact.
6. Extract the downloaded artifact ZIP on your phone and tap `app-debug.apk` to install. Android may ask you to allow installation from that browser or file manager.

This produces a debug/testing APK, not a Play Store release. Keep the repository private if you do not want the source code public. GitHub may require account verification and has usage limits.
